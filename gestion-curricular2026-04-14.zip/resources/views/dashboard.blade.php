@extends('templates.master')
@section('content')
<h2>Aplicación Gestión curricular</h2>
@endsection