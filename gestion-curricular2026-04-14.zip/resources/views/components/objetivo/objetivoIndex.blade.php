<?php

use Livewire\Component;

new class extends Component
{
    public $search = '';
    public $objetivos = [];
    public $competencias = [];

    public function mount()
    {
        $this->cargarObjetivos();
        $this->cargarCompetencias();
    }

    public function updatedSearch()
    {
        $this->cargarObjetivos();
    }

    public function cargarObjetivos()
    {
        $this->objetivos = DB::table('objetivo')
        ->where('obj_descripcion', 'like', '%' . $this->search . '%')
            ->orderBy('obj_id', 'desc')
            ->get();
    }

    public function guardarCambios()
    {
        foreach ($this->objetivos as $objetivo) {

            DB::table('objetivo')
                ->where('obj_id', $objetivo->obj_id)
                ->update([
                    'obj_descripcion' => $objetivo->obj_descripcion,
                    'com_id' => $objetivo->com_id
                ]);
        }

        session()->flash('success', 'Actualizados exitosa');

        $this->cargarObjetivos();
    }

    public function eliminar($id)
    {
        DB::table('objetivo')
            ->where('obj_id', $id)
            ->delete();

        session()->flash('success', 'Eliminación exitosa');

        $this->cargarObjetivos();
    }

    public function cargarCompetencias()
    {
        $this->competencias = DB::table('competencia')
            ->orderBy('com_id', 'desc')
            ->get();
    }
};
?>

<div>
    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="container my-4">

    <div class="card shadow-sm">
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Objetivo</h4>

            <!-- 🔍 Buscador -->
            <input
                type="text"
                class="form-control w-50"
                placeholder="Buscar..."
                wire:model.live="search"
            >
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Objetivo</th>
                            <th>Competencia</th>
                            <th>Creado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($objetivos as $objetivo)
                            <tr>
                                <td>{{ $objetivo->obj_id }}</td>
                                <td><input wire:model="objetivos.{{ $loop->index }}.obj_descripcion" class="form-control" type="text" value="{{ $objetivo->obj_descripcion }}"></td>
                                <td>
                                    <select class="form-control" wire:model="objetivos.{{ $loop->index }}.com_id">
                                        @forelse ($competencias as $comp)
                                            <option value="{{ $comp->com_id }}">
                                                {{ $comp->com_descripcion }}
                                            </option>
                                        @empty
                                            <option>Sin competencias</option>
                                        @endforelse

                                    </select>
                                </td>
                                <td>{{ $objetivo->created_at }}</td>
                                <td><button
                                    class="btn btn-danger"
                                    wire:click="eliminar({{ $objetivo->obj_id }})"
                                    wire:confirm="¿Seguro que deseas eliminar esta objetivo?">Eliminar</button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted">
                                    No hay resultados
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-center text-muted">
                                <a class="btn btn-success" wire:click="guardarCambios">Guardar cambios</a>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

</div>
</div>