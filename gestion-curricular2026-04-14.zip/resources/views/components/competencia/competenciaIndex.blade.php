<?php

use Livewire\Component;

new class extends Component
{
    public $search = '';
    public $competencias = [];

    public function mount()
    {
        $this->cargarCompetencia();
    }

    public function updatedSearch()
    {
        $this->cargarCompetencia();
    }

    public function cargarCompetencia()
    {
        $this->competencias = DB::table('competencia')
        ->where('com_descripcion', 'like', '%' . $this->search . '%')
            ->orderBy('com_id', 'desc')
            ->get();
    }

    public function guardarCambios()
    {
        foreach ($this->competencias as $competencia) {

            DB::table('competencia')
                ->where('com_id', $competencia->com_id)
                ->update([
                    'com_descripcion' => $competencia->com_descripcion
                ]);
        }

        session()->flash('success', 'Actualizados exitosa');

        $this->cargarCompetencia();
    }

    public function eliminar($id)
    {
        DB::table('competencia')
            ->where('com_id', $id)
            ->delete();

        session()->flash('success', 'Eliminación exitosa');

        $this->cargarCompetencia();
    }
};
?>

<div>
    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="container my-4">

    <div class="card shadow-sm">
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Competencia</h4>

            <!-- 🔍 Buscador -->
            <input
                type="text"
                class="form-control w-50"
                placeholder="Buscar..."
                wire:model.live="search"
            >
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Competencia</th>
                            <th>Creado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($competencias as $competencia)
                            <tr>
                                <td>{{ $competencia->com_id }}</td>
                                <td><input wire:model="competencias.{{ $loop->index }}.com_descripcion" class="form-control" type="text" value="{{ $competencia->com_descripcion }}"></td>
                                <td>{{ $competencia->created_at }}</td>
                                <td><button
                                    class="btn btn-danger"
                                    wire:click="eliminar({{ $competencia->com_id }})"
                                    wire:confirm="¿Seguro que deseas eliminar esta competencia?">Eliminar</button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted">
                                    No hay resultados
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-center text-muted">
                                <a class="btn btn-success" wire:click="guardarCambios">Guardar cambios</a>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

</div>
</div>