<?php

use Livewire\Component;

new class extends Component
{
    public $search = '';
    public $cursos = [];

    public function mount()
    {
        $this->cargarcurso();
    }

    public function updatedSearch()
    {
        $this->cargarcurso();
    }

    public function cargarcurso()
    {
        $this->cursos = DB::table('curso')
        ->where('cur_descripcion', 'like', '%' . $this->search . '%')
            ->orderBy('cur_id', 'desc')
            ->get();
    }

    public function guardarCambios()
    {
        foreach ($this->cursos as $curso) {

            DB::table('curso')
                ->where('cur_id', $curso->cur_id)
                ->update([
                    'cur_descripcion' => $curso->cur_descripcion
                ]);
        }

        session()->flash('success', 'Todos los cursos fueron actualizados correctamente');

        $this->cargarcurso();
    }

    public function eliminar($id)
    {
        DB::table('curso')
            ->where('cur_id', $id)
            ->delete();

        session()->flash('success', 'Curso eliminado correctamente');

        $this->cargarcurso();
    }
};
?>

<div>
    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="container my-4">

    <div class="card shadow-sm">
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Cursos</h4>

            <!-- 🔍 Buscador -->
            <input
                type="text"
                class="form-control w-50"
                placeholder="Buscar..."
                wire:model.live="search"
            >
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Curso</th>
                            <th>Creado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($cursos as $curso)
                            <tr>
                                <td>{{ $curso->cur_id }}</td>
                                <td><input wire:model="cursos.{{ $loop->index }}.cur_descripcion" class="form-control" type="text" value="{{ $curso->cur_descripcion }}"></td>
                                <td>{{ $curso->created_at }}</td>
                                <td><button
                                    class="btn btn-danger"
                                    wire:click="eliminar({{ $curso->cur_id }})"
                                    wire:confirm="¿Seguro que deseas eliminar este curso?">Eliminar</button>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="3" class="text-center text-muted">
                                    No hay resultados
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-center text-muted">
                                <a class="btn btn-success" wire:click="guardarCambios">Guardar cambios</a>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

</div>
    
    
</div>