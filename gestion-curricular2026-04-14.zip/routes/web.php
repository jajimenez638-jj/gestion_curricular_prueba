<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Modules\ProgramaController;
use App\Http\Controllers\Modules\ProgramadetalleController;
use App\Http\Controllers\Modules\CursoController;
use App\Http\Controllers\Modules\CompetenciaController;
use App\Http\Controllers\Modules\ObjetivoController;
use Illuminate\Support\Facades\Route;

Route::get('/', [DashboardController::class, 'getIndex']);

Route::get('/objetivo', [ObjetivoController::class, 'getIndex']);
Route::get('/programa', [ProgramaController::class, 'getIndex']);
Route::get('/curso', [CursoController::class, 'getIndex']);
Route::get('/competencia', [CompetenciaController::class, 'getIndex']);
Route::get('/programaDetalle/{id}', [ProgramadetalleController::class, 'getIndex']);
